package org.micromanager.api.events;

// This class signals when any property of the microscope has changed. 
public class PropertiesChangedEvent {
}

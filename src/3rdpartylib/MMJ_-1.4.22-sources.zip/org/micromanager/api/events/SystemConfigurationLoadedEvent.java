package org.micromanager.api.events;

//This class signals when a configuration file is loaded. 
public class SystemConfigurationLoadedEvent {
}

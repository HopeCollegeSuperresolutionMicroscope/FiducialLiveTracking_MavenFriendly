package org.micromanager.imagedisplay;


// This class is used to notify entities that drawing logic is about to be 
// invoked.
public class DrawEvent {
}

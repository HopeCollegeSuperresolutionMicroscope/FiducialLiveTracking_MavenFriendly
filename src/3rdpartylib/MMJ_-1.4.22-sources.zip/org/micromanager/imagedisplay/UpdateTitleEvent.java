package org.micromanager.imagedisplay;

// This class signifies that the display window's title should be re-set.
class UpdateTitleEvent {}

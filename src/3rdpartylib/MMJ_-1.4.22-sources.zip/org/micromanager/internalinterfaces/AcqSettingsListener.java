
package org.micromanager.internalinterfaces;

/**
 *
 * @author Arthur
 */
public interface AcqSettingsListener {
    public void settingsChanged();
}

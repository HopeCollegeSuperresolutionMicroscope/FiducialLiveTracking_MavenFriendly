package org.micromanager.positionlist;

// This class signifies that the stage movers available has changed.
public class MoversChangedEvent {}

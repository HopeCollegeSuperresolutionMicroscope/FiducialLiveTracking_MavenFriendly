
package org.micromanager.utils;

/**
 *
 * @author arthur
 */
public interface MMPropertyTableModel {
    public PropertyItem getPropertyItem(int rowIndex);
}
